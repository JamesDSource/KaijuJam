BINDIR = '/usr/local/bin'
LIBDIR = '/usr/local/lib'
PREFIX = '/usr/local'
